from controllers.main_controller import *
from controllers.product_controller import *

if __name__ == '__main__':
    app.run(debug=True)
